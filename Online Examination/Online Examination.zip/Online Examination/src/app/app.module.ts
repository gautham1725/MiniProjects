import { QuizService } from './../quiz/quiz.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { QuizComponent } from './../quiz/quiz.component';
import { RegistrationComponent } from './../registration/registration.component';
import { ReactiveFormsModule, FormsModule, Validators } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent , RegistrationComponent , QuizComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [Validators,QuizComponent],
  bootstrap: [AppComponent]
})

export class AppModule { }
